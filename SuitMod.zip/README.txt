All suits match the corresponding bases on the map!

Side note: Megacorp is also white due to shared colors with Pentacom, nothing I can do.

To install drag the model folder into "\SteamLibrary\steamapps\common\Sub Rosa\data" replace, and you're good to go.